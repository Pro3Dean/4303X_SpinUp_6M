using namespace vex;

extern brain Brain;

extern motor FrontLeft;
extern motor MiddleLeft;
extern motor BackLeft;
extern motor_group LeftDrive6;
extern motor_group LeftDrive4;
extern controller Controller1;
extern motor FrontRight;
extern motor MiddleRight;
extern motor BackRight;
extern motor_group RightDrive6;
extern motor_group RightDrive4;
extern motor LeftIntake;
extern motor RightIntake;
extern motor_group Intake;
extern motor TopFlywheel;
extern motor BotFlywheel;
extern motor_group Flywheel;
extern digital_out PTO;
extern digital_out Actuator;
extern digital_out Endgame;
extern inertial Inertial;

void vexcodeInit(void);
