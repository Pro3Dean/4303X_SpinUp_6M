#include "vex.h"
using namespace vex;

double averagePosition;
double error;
double integral;
double derivative;
double prevError;
double speed;
void drivePID(double target, bool Drive4 = false, bool driveIntake = false, double kP = 1.4, double kD = 5.5);
void gyroPID(double targetAngle, bool drive4 = false, double turnKP = 0.98, double turnKD = 5.5);
void turnRight(float degrees, bool drive4 = false);
void driveIt(float inches, bool drive4 = false, bool intakeWhileDrive = false);