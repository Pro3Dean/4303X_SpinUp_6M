/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "PID.h"
#include "Functions.h"

using namespace vex;

bool intake_ON = true;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here


void rotateRight(double angleTurn){
  Inertial.resetRotation();

  RightDrive4.spin(directionType::rev, 60, percentUnits::pct);
	LeftDrive4.spin(directionType::fwd, 60, percentUnits::pct);

  double ratio = (Inertial.rotation(rotationUnits::deg)) / -(angleTurn);

  while((Inertial.rotation(rotationUnits::deg) + 12.95) < angleTurn){
    RightDrive4.spin(directionType::rev, 60 - ratio*50, percentUnits::pct);
    LeftDrive4.spin(directionType::fwd, 60 - ratio*50, percentUnits::pct);
    ratio = (Inertial.rotation(rotationUnits::deg)) / angleTurn;
  }
  RightDrive4.stop(brakeType::hold);
  LeftDrive4.stop(brakeType::hold);

}
/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  Controller1.Screen.clearScreen();
  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print("Calibrating");

  PTO.set(false);
  intake_ON = true;
  Actuator.set(false);
  pistonOutOn = false;
  Actuator.set(false);
  pistonOutOn = true;
  Inertial.calibrate(2000);
  task::sleep(2000);
  Controller1.Screen.clearScreen();

  Flywheel.setVelocity(flywheelPct, velocityUnits::pct);
  Intake.setVelocity(100, percentUnits::pct);
  BotFlywheel.setBrake(brakeType::coast);
  TopFlywheel.setBrake(brakeType::coast);
  Intake.setStopping(brakeType::brake);
  FrontLeft.setBrake(brakeType::brake);
  FrontRight.setBrake(brakeType::brake);
  MiddleLeft.setBrake(brakeType::brake);
  MiddleRight.setBrake(brakeType::brake);
  BackLeft.setBrake(brakeType::brake);
  BackRight.setBrake(brakeType::brake);

  drawMenuScreen();
     while(true){
 waitUntil(Brain.Screen.pressing());

 if(pageSelect == 0){
  if(Brain.Screen.xPosition() < 440 && Brain.Screen.xPosition() > 335 && Brain.Screen.yPosition() < 100 && Brain.Screen.yPosition() > 20){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();   //blue
    drawAutoSelect();
    pageSelect = 2;
  }else if(Brain.Screen.xPosition() < 155 && Brain.Screen.xPosition() > 50 && Brain.Screen.yPosition() < 100 && Brain.Screen.yPosition() > 20){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();   //red
    drawAutoSelect();
    pageSelect = 1;
  }if(Brain.Screen.xPosition() < 155 && Brain.Screen.xPosition() > 50 && Brain.Screen.yPosition() < 200 && Brain.Screen.yPosition() > 120){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();   //skills
    drawSkills();
    pageSelect = 3;
  }if(Brain.Screen.xPosition() < 440 && Brain.Screen.xPosition() > 335 && Brain.Screen.yPosition() < 200 && Brain.Screen.yPosition() > 120){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();   //flywheel
    drawFlywheelControl();
    pageSelect = 4;
  }if(Brain.Screen.xPosition() < 305 && Brain.Screen.xPosition() > 185 && Brain.Screen.yPosition() < 160 && Brain.Screen.yPosition() > 40){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();   //variable
    drawVariableControl();
    pageSelect = 5;
  }
 }
 if(pageSelect == 1){ //Red
    Brain.Screen.setFillColor(white);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 0;
  if(Brain.Screen.xPosition() < 240 && Brain.Screen.xPosition() > 135){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawAutoSelect();
    Brain.Screen.setFillColor(red);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 1;
  }if(Brain.Screen.xPosition() < 355 && Brain.Screen.xPosition() > 250){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawAutoSelect();
    Brain.Screen.setFillColor(blue);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 2;
  }if(Brain.Screen.xPosition() < 470 && Brain.Screen.xPosition() > 365){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawAutoSelect();
    Brain.Screen.setFillColor(yellow);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 3;
  }if(Brain.Screen.xPosition() < 305 && Brain.Screen.xPosition() > 200 && Brain.Screen.yPosition() > 115){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawMenuScreen();
    pageSelect = 0;
  }
 }
 if(pageSelect == 2){             //blue
 Brain.Screen.setFillColor(white);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 0;
  if(Brain.Screen.xPosition() < 240 && Brain.Screen.xPosition() > 135){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawAutoSelect();
    Brain.Screen.setFillColor(red);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 1;
  }if(Brain.Screen.xPosition() < 355 && Brain.Screen.xPosition() > 250){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawAutoSelect();
    Brain.Screen.setFillColor(blue);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 2;
  }if(Brain.Screen.xPosition() < 470 && Brain.Screen.xPosition() > 365){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawAutoSelect();
    Brain.Screen.setFillColor(yellow);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 3;
  }if(Brain.Screen.xPosition() < 305 && Brain.Screen.xPosition() > 200 && Brain.Screen.yPosition() > 115){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawMenuScreen();
    pageSelect = 0;
  }
 }
  if(pageSelect == 3){
    Brain.Screen.setFillColor(white);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 0;
  if(Brain.Screen.xPosition() < 240 && Brain.Screen.xPosition() > 135){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawSkills();
    Brain.Screen.setFillColor(red);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 1;
  }if(Brain.Screen.xPosition() < 355 && Brain.Screen.xPosition() > 250){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawSkills();
    Brain.Screen.setFillColor(blue);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 2;
  }if(Brain.Screen.xPosition() < 305 && Brain.Screen.xPosition() > 200 && Brain.Screen.yPosition() > 115){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawMenuScreen();
    pageSelect = 0;
  }
}
if(pageSelect == 4){
  if(Brain.Screen.xPosition() < 125 && Brain.Screen.xPosition() > 20){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawMenuScreen();
    pageSelect = 0;
  }if(Brain.Screen.xPosition() < 250 && Brain.Screen.xPosition() > 200 && Brain.Screen.yPosition() < 100){
      if(flywheelPct >= 100){
        flywheelPct = 100;
      }else{
      wait(250, timeUnits::msec);
      flywheelPct += 5;
      Brain.Screen.clearScreen();
      drawFlywheelControl();
      Brain.Screen.setPenColor(black);
      Brain.Screen.setCursor(2, 23);
      Brain.Screen.print(static_cast<int>(flywheelPct));
      }
  }if(Brain.Screen.xPosition() < 250 && Brain.Screen.xPosition() > 200 && Brain.Screen.yPosition() > 190){
      if(flywheelPct <= 0){
        flywheelPct = 0;
      }else{
        wait(250, timeUnits::msec);
        flywheelPct -= 5;
        Brain.Screen.clearScreen();
        drawFlywheelControl();
        Brain.Screen.setPenColor(black);
        Brain.Screen.setCursor(2, 23);
        Brain.Screen.print(static_cast<int>(flywheelPct));
      }
  }if(Brain.Screen.xPosition() < 470 && Brain.Screen.xPosition() > 365 && Brain.Screen.yPosition() < 100){
      wait(250, timeUnits::msec);
    Brain.Screen.setCursor(8, 35);
    Brain.Screen.print("SPINNING!");
    Flywheel.spin(directionType::fwd, flywheelPct, percentUnits::pct);
      wait(2.5, timeUnits::sec);
      Flywheel.spin(directionType::fwd, flywheelPct, percentUnits::pct);
      Brain.Screen.clearLine(8);
      Brain.Screen.setCursor(8, 35);
      Brain.Screen.print("FIRING!!!");
      wait(5, timeUnits::sec);
      Actuator.set(true);
      pistonOutOn = false;
      wait(100, timeUnits::msec);
      Actuator.set(false);
      pistonOutOn = true;
      wait(250, timeUnits::msec);
      Flywheel.stop(brakeType::coast);
      Brain.Screen.clearScreen();
      drawFlywheelControl();
      Brain.Screen.setPenColor(black);
      Brain.Screen.setCursor(2, 23);
      Brain.Screen.print(static_cast<int>(flywheelPct));
  }
}
if(pageSelect == 5){
   if(Brain.Screen.xPosition() < 85 && Brain.Screen.xPosition() > 5 && Brain.Screen.yPosition() < 45 && Brain.Screen.yPosition() > 5){
      wait(250, timeUnits::msec);
      Brain.Screen.clearScreen();
      drawMenuScreen();
      pageSelect = 0;
  }if(Brain.Screen.xPosition() < 65 && Brain.Screen.xPosition() > 25 && Brain.Screen.yPosition() < 125 && Brain.Screen.yPosition() > 85){
      wait(250, timeUnits::msec);
      screenKP += 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 65 && Brain.Screen.xPosition() > 25 && Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() > 175){
      wait(250, timeUnits::msec);
      screenKP -= 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 135 && Brain.Screen.xPosition() > 95 && Brain.Screen.yPosition() < 125 && Brain.Screen.yPosition() > 85){
      wait(250, timeUnits::msec);
      screenKI += 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 135 && Brain.Screen.xPosition() > 95 && Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() > 175){
      wait(250, timeUnits::msec);
      screenKI -= 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 205 && Brain.Screen.xPosition() > 165 && Brain.Screen.yPosition() < 125 && Brain.Screen.yPosition() > 85){
      wait(250, timeUnits::msec);
      screenKD += 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 205 && Brain.Screen.xPosition() > 165 && Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() > 175){
      wait(250, timeUnits::msec);
      screenKD -= 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 270 && Brain.Screen.xPosition() > 230 && Brain.Screen.yPosition() < 125 && Brain.Screen.yPosition() > 85){
      wait(250, timeUnits::msec);
      screenTurnKP += 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 270 && Brain.Screen.xPosition() > 230 && Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() > 175){
      wait(250, timeUnits::msec);
      screenTurnKP -= 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 335 && Brain.Screen.xPosition() > 295 && Brain.Screen.yPosition() < 125 && Brain.Screen.yPosition() > 85){
      wait(250, timeUnits::msec);
      screenTurnKI += 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 335 && Brain.Screen.xPosition() > 295 && Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() > 175){
      wait(250, timeUnits::msec);
      screenTurnKI -= 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 405 && Brain.Screen.xPosition() > 365 && Brain.Screen.yPosition() < 125 && Brain.Screen.yPosition() > 85){
      wait(250, timeUnits::msec);
      screenTurnKD += 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 405 && Brain.Screen.xPosition() > 365 && Brain.Screen.yPosition() < 215 && Brain.Screen.yPosition() > 175){
      wait(250, timeUnits::msec);
      screenTurnKD -= 0.05;
      Brain.Screen.clearScreen();
      drawVariableControl();
  }if(Brain.Screen.xPosition() < 320 && Brain.Screen.xPosition() > 215 && Brain.Screen.yPosition() < 45 && Brain.Screen.yPosition() > 5){
      wait(250, timeUnits::msec);
      Brain.Screen.clearScreen();
      pageSelect = 6;
  }if(Brain.Screen.xPosition() < 435 && Brain.Screen.xPosition() > 330 && Brain.Screen.yPosition() < 45 && Brain.Screen.yPosition() > 5){
      wait(250, timeUnits::msec);
      Brain.Screen.clearScreen();
      drawVariableTest();
      pageSelect = 7;
  }
}if(pageSelect == 7){
    drawVariableMenu();
    Brain.Screen.setFillColor(white);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 0;
  if(Brain.Screen.xPosition() < 205 && Brain.Screen.xPosition() > 5 && Brain.Screen.yPosition() < 45 && Brain.Screen.yPosition() > 5){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawVariableMenu();
    drawVariableControl();
    pageSelect = 5;
  }if(Brain.Screen.xPosition() < 320 && Brain.Screen.xPosition() > 215 && Brain.Screen.yPosition() < 45 && Brain.Screen.yPosition() > 5){
      wait(250, timeUnits::msec);
      Brain.Screen.clearScreen();
      pageSelect = 6;
  }if(Brain.Screen.xPosition() < 240 && Brain.Screen.xPosition() > 135 && Brain.Screen.yPosition() > 50){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawVariableMenu();
    drawVariableTest();
    Brain.Screen.setFillColor(red);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 1;
  }if(Brain.Screen.xPosition() < 355 && Brain.Screen.xPosition() > 250 && Brain.Screen.yPosition() > 50){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawVariableMenu();
    drawVariableTest();
    Brain.Screen.setFillColor(blue);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 2;
  }if(Brain.Screen.xPosition() < 470 && Brain.Screen.xPosition() > 365 && Brain.Screen.yPosition() > 50){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawVariableMenu();
    drawVariableTest();
    Brain.Screen.setFillColor(yellow);
    Brain.Screen.drawRectangle(20, 200, 440, 10);
    autonSelect = 3;
  }if(Brain.Screen.xPosition() < 305 && Brain.Screen.xPosition() > 200 && Brain.Screen.yPosition() > 135){
    wait(250, timeUnits::msec);
    Brain.Screen.clearScreen();
    drawMenuScreen();
    pageSelect = 0;
  }if(Brain.Screen.xPosition() < 110 && Brain.Screen.xPosition() > 5 && Brain.Screen.yPosition() < 100 && Brain.Screen.yPosition() > 20){
    wait(250, timeUnits::msec);
    if(pageSelect == 7){
      if(autonSelect == 1){
        drivePID(24, 0, false, screenKP, screenKD);
      }else if(autonSelect == 2){
        turning(90, false);
      }else if(autonSelect == 3){
        drivePID(24, true, true, screenKP, screenKD);
      }
    }
  }
}
}
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  Flywheel.spin(directionType::fwd, 9.425, voltageUnits::volt);
  turning(24);
  wait(2500, timeUnits::msec);
  Actuator.set(true);
  wait(10, timeUnits::msec);
  Actuator.set(false);
  wait(1000, timeUnits::msec);
  Actuator.set(true);
  wait(10, timeUnits::msec);
  Actuator.set(false);
  wait(100, timeUnits::msec);
  Flywheel.stop(brakeType::coast);
  turning(90-24);
  wait(100, timeUnits::msec);
  driveIt(24);
  turning(-90);
  wait(100, timeUnits::msec);
  Intake.spinFor(directionType::fwd, 90, rotationUnits::deg);
  driveIt(-12);
  wait(100, timeUnits::msec);
  driveIt(5);
  turning(90+45);
  wait(100, timeUnits::msec);
  Intake.spin(directionType::fwd);
  driveIt(48);
  wait(500, timeUnits::msec);
  Flywheel.spin(directionType::fwd, 9.425, voltageUnits::volt);
  turning(90+24);
  wait(2500, timeUnits::msec);
  Actuator.set(true);
  wait(10, timeUnits::msec);
  Actuator.set(false);
  wait(1000, timeUnits::msec);
  Actuator.set(true);
  wait(10, timeUnits::msec);
  Actuator.set(false);
  wait(1000, timeUnits::msec);
  Actuator.set(true);
  wait(10, timeUnits::msec);
  Actuator.set(false);
  wait(100, timeUnits::msec);
  Flywheel.stop(brakeType::coast);
  if(pageSelect == 1 || pageSelect == 2){      //RED
    if(autonSelect == 1){ //AWP

    }else if(autonSelect == 2){ //Roller

    }else if(autonSelect == 3){ //Tape

    }
  }else if(pageSelect == 3){
    if(autonSelect == 1){

    }else if(autonSelect == 2){

    }
  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {

    while(intake_ON == false){
      PTO.set(true);
      LeftDrive6.spin(directionType::fwd, Controller1.Axis3.position(), percentUnits::pct);
      RightDrive6.spin(directionType::fwd, Controller1.Axis2.position(), percentUnits::pct);

      if(Controller1.ButtonX.pressing()){
        PTO.set(false);
        intake_ON = true;
      }

      if(Controller1.ButtonL1.pressing()){
        Flywheel.spin(directionType::fwd, 8.5, voltageUnits::volt);
      }else{
        Flywheel.stop(brakeType::coast);
      }

      if(Controller1.ButtonR1.pressing()){
        Actuator.set(true);
      }else{
        Actuator.set(false);
      }

      if(Controller1.ButtonR2.pressing() && Controller1.ButtonR1.pressing()){
        Endgame.set(true);
      }else{
        Endgame.set(false);
      }


    }while(intake_ON == true){
      LeftDrive4.spin(directionType::fwd, Controller1.Axis3.position(), percentUnits::pct);
      RightDrive4.spin(directionType::fwd, Controller1.Axis2.position(), percentUnits::pct);

      if(Controller1.ButtonDown.pressing()){
        Intake.spin(directionType::fwd, 120, voltageUnits::volt);
      }else if(Controller1.ButtonUp.pressing()){
        Intake.spin(directionType::rev, 60, voltageUnits::volt);
      }else if(Controller1.ButtonRight.pressing()){
        Intake.spin(directionType::rev, 5, voltageUnits::volt);
      }else{
        Intake.stop(brakeType::coast);
      }

      if(Controller1.ButtonB.pressing()){
        PTO.set(true);
        intake_ON = false;
      }

      if(Controller1.ButtonL1.pressing()){
        Flywheel.spin(directionType::fwd, 8.5, voltageUnits::volt);
      }else{
        Flywheel.stop(brakeType::coast);
      }

      if(Controller1.ButtonR1.pressing()){
        Actuator.set(true);
      }else{
        Actuator.set(false);
      }

      if(Controller1.ButtonR2.pressing() && Controller1.ButtonL2.pressing()){
        Endgame.set(true);
      }else{
        Endgame.set(false);
      }

    }
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
