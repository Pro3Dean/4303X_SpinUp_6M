#include "vex.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;

motor FrontLeft = motor(PORT18, ratio18_1, true);
motor MiddleLeft = motor(PORT14, ratio18_1, true);
motor BackLeft = motor(PORT13, ratio18_1, true);
motor_group LeftDrive6 = motor_group(FrontLeft, MiddleLeft,  BackLeft);
motor_group LeftDrive4 = motor_group(FrontLeft, BackLeft);

controller Controller1 = controller(primary);
motor FrontRight = motor(PORT7, ratio18_1, false);
motor MiddleRight = motor(PORT9, ratio18_1, false);
motor BackRight = motor(PORT15, ratio18_1, false);
motor_group RightDrive6 = motor_group(FrontRight, MiddleRight, BackRight);
motor_group RightDrive4 = motor_group(FrontRight, BackRight);

motor LeftIntake = motor(PORT14, ratio18_1, true);
motor RightIntake = motor(PORT9, ratio18_1, false);
motor_group Intake = motor_group(LeftIntake, RightIntake);

motor TopFlywheel = motor(PORT6, ratio6_1, false);
motor BotFlywheel = motor(PORT4, ratio6_1, true);
motor_group Flywheel = motor_group(TopFlywheel, BotFlywheel);

digital_out PTO = digital_out(Brain.ThreeWirePort.A);
digital_out Actuator = digital_out(Brain.ThreeWirePort.B);
digital_out Endgame = digital_out(Brain.ThreeWirePort.C);

inertial Inertial = inertial(PORT1);

void vexcodeInit(void) {
  // Nothing to initialize
}