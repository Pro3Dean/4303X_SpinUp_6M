#include "vex.h"
#include "vex_vision.h"
using namespace vex;

int autonSelect = 2;
int pageSelect = 0;  //pageSelect 0 is menu, 1 is red, 2 is blue, 3 is skills, 4 is flywheel, 5 is variables, 7 is variable test
int flywheelPct = 75;
double screenKP = 1.4;
double screenKI = 0;
double screenKD = 5.5;
double screenTurnKP = 0.98;
double screenTurnKI = 0;
double screenTurnKD = 5.5;

void drawMenuScreen(){
  Brain.Screen.setPenColor(color::white);

  Brain.Screen.setFillColor(color::red);
  Brain.Screen.drawRectangle(50, 20, 105, 80);
  Brain.Screen.setCursor(4, 10);
  Brain.Screen.print("Red");

  Brain.Screen.setFillColor(color::blue);
  Brain.Screen.drawRectangle(335, 20, 105, 80);
  Brain.Screen.setCursor(4, 37);
  Brain.Screen.print("Blue");

  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(50, 120, 105, 80);
  Brain.Screen.setCursor(8, 8);
  Brain.Screen.print("Skills");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(yellow);
  Brain.Screen.drawRectangle(335, 120, 105, 80);
  Brain.Screen.setCursor(8, 36);
  Brain.Screen.print("Flywheel");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawCircle(245, 100, 60);
  Brain.Screen.setCursor(6, 21);
  Brain.Screen.print("Variables");
}

void drawVariableTest(){
  Brain.Screen.setFillColor(red);
  
  Brain.Screen.drawRectangle(135, 50, 105, 80);
  Brain.Screen.setCursor(5, 16);
  Brain.Screen.print("6drivePID");
  
  Brain.Screen.setFillColor(blue);
  Brain.Screen.drawRectangle(250, 50, 105, 80);
  Brain.Screen.setCursor(5, 28);
  Brain.Screen.print("gyroPID");

  Brain.Screen.setFillColor(yellow);
  Brain.Screen.drawRectangle(365, 50, 105, 80);
  Brain.Screen.setCursor(5, 36);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print("IntakePID");

  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(200, 135, 105, 60);
  Brain.Screen.setCursor(9, 24);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print("Back");

  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(5, 50, 105, 80);
  Brain.Screen.setCursor(5, 5);
  Brain.Screen.print("PLAY");
}

void drawVariableMenu(){
  Brain.Screen.setPenColor(color::white);

  Brain.Screen.setFillColor(color::red);
  Brain.Screen.drawRectangle(100, 5, 105, 40);
  Brain.Screen.setCursor(2, 12);
  Brain.Screen.print("Variables");

  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(330, 5, 105, 40);
  Brain.Screen.setCursor(2, 37);
  Brain.Screen.print("Test");
}

void drawFlywheelControl(){
  int flywheelPct = 75;
  Brain.Screen.setPenColor(black);
  
  Brain.Screen.setFillColor(yellow);
  Brain.Screen.drawRectangle(175, 100, 105, 80);
  Brain.Screen.setCursor(8, 20);
  Brain.Screen.print("Flywheel");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(2, 23);
  Brain.Screen.print(static_cast<int>(flywheelPct));

  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(200, 50, 50, 50);
  Brain.Screen.setCursor(4, 23);
  Brain.Screen.print("+");

  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(200, 175, 50, 50);
  Brain.Screen.setCursor(11, 23);
  Brain.Screen.print("-");

  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(20, 20, 105, 60);
  Brain.Screen.setCursor(3, 4);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print("Back");

  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(365, 20, 105, 80);
  Brain.Screen.setCursor(3, 38);
  Brain.Screen.print("SHOOT");
}

void drawVariableControl(){
  drawVariableMenu();
  Brain.Screen.setPenColor(white);

  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(5, 5, 80, 40);
  Brain.Screen.setCursor(2, 3);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print("Back");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(4, 4);
  Brain.Screen.print("kP");
  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(20, 125, 50, 50);
  Brain.Screen.setCursor(8, 3);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print(static_cast<double>(screenKP));
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(25, 85, 40, 40);
  Brain.Screen.setCursor(6, 5);
  Brain.Screen.print("+");
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(25, 175, 40, 40);
  Brain.Screen.setCursor(10, 5);
  Brain.Screen.print("-");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(4, 12);
  Brain.Screen.print("kI");
  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(90, 125, 50, 50);
  Brain.Screen.setCursor(8, 10);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print(static_cast<double>(screenKI));
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(95, 85, 40, 40);
  Brain.Screen.setCursor(6, 12);
  Brain.Screen.print("+");
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(95, 175, 40, 40);
  Brain.Screen.setCursor(10, 12);
  Brain.Screen.print("-");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(4, 18);
  Brain.Screen.print("kD");
  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(160, 125, 50, 50);
  Brain.Screen.setCursor(8, 18);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print(static_cast<double>(screenKD));
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(165, 85, 40, 40);
  Brain.Screen.setCursor(6, 19);
  Brain.Screen.print("+");
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(165, 175, 40, 40);
  Brain.Screen.setCursor(10, 19);
  Brain.Screen.print("-");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(4, 23);
  Brain.Screen.print("turnKP");
  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(225, 125, 50, 50);
  Brain.Screen.setCursor(8, 24);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print(static_cast<double>(screenTurnKP));
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(230, 85, 40, 40);
  Brain.Screen.setCursor(6, 26);
  Brain.Screen.print("+");
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(230, 175, 40, 40);
  Brain.Screen.setCursor(10, 26);
  Brain.Screen.print("-");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(4, 30);
  Brain.Screen.print("turnKI");
  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(290, 125, 50, 50);
  Brain.Screen.setCursor(8, 30);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print(static_cast<double>(screenTurnKI));
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(295, 85, 40, 40);
  Brain.Screen.setCursor(6, 32);
  Brain.Screen.print("+");
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(295, 175, 40, 40);
  Brain.Screen.setCursor(10, 32);
  Brain.Screen.print("-");

  Brain.Screen.setPenColor(black);
  Brain.Screen.setCursor(4, 37);
  Brain.Screen.print("turnKD");
  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(360, 125, 50, 50);
  Brain.Screen.setCursor(8, 37);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print(static_cast<double>(screenTurnKD));
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(365, 85, 40, 40);
  Brain.Screen.setCursor(6, 40);
  Brain.Screen.print("+");
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(365, 175, 40, 40);
  Brain.Screen.setCursor(10, 40);
  Brain.Screen.print("-");
}

void drawAutoSelect(){
  Brain.Screen.setPenColor(white);

  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(135, 20, 105, 80);
  Brain.Screen.setCursor(3, 16);
  Brain.Screen.print("AWP");
  
  Brain.Screen.setFillColor(blue);
  Brain.Screen.drawRectangle(250, 20, 105, 80);
  Brain.Screen.setCursor(3, 28);
  Brain.Screen.print("Roller");

  Brain.Screen.setFillColor(yellow);
  Brain.Screen.drawRectangle(365, 20, 105, 80);
  Brain.Screen.setCursor(3, 38);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print("Tape");

  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(200, 115, 105, 60);
  Brain.Screen.setCursor(8, 24);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print("Back");

  }

void drawSkills(){
  Brain.Screen.setPenColor(white);
  
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(135, 20, 105, 80);
  Brain.Screen.setCursor(3, 16);
  Brain.Screen.print("Red Side");
  Brain.Screen.setCursor(4, 17);
  Brain.Screen.print("Start");
  
  Brain.Screen.setFillColor(blue);
  Brain.Screen.drawRectangle(250, 20, 105, 80);
  Brain.Screen.setCursor(3, 27);
  Brain.Screen.print("Blue Side");
  Brain.Screen.setCursor(4, 27);
  Brain.Screen.print("Start");

  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(200, 115, 105, 60);
  Brain.Screen.setCursor(8, 24);
  Brain.Screen.setPenColor(black);
  Brain.Screen.print("Back");
}

bool pistonOutOn = false;
bool EndgameActive = false;
