#include "vex.h"
#include "vex_imu.h"
#include "vex_units.h"
using namespace vex;

void gyroPID(double targetAngle, bool drive4 = false, double turnKP = 0.98, double turnKD = 0/*5.5*/){
  if(drive4 == true){
    PTO.set(false);
    double threshold = 1;
    /*if(targetAngle <- 0.0){
      threshold = 1.5;
    }
    else{
      threshold = 0.7;
    }*/

    double error = targetAngle - Inertial.rotation(rotationUnits::deg);
    double derivative;
    double prevError;

    while(fabs(error) > threshold){
      error = targetAngle - Inertial.rotation(rotationUnits::deg);

      derivative = error - prevError;
      prevError = error;
      double p = error * turnKP;
      double d = derivative * turnKD;

      double vel = p + d;

      FrontLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      FrontRight.spin(directionType::rev, vel, voltageUnits::volt);
      BackLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      BackRight.spin(directionType::rev, vel, voltageUnits::volt);
    }
    FrontLeft.stop();
    FrontRight.stop();
    BackLeft.stop();
    BackRight.stop();
  }else if(drive4 == false){
    PTO.set(true);
    double threshold = 1;
    /*if(targetAngle <- 0.0){
      threshold = 1.5;
    }
    else{
      threshold = 0.7;
    }*/

    double error = targetAngle - Inertial.rotation(rotationUnits::deg);
    double derivative;
    double prevError;

    while(fabs(error) > threshold){
      error = targetAngle - Inertial.rotation(rotationUnits::deg);

      derivative = error - prevError;
      prevError = error;
      double p = error * turnKP;
      double d = derivative * turnKD;

      double vel = p + d;

      FrontLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      FrontRight.spin(directionType::rev, vel, voltageUnits::volt);
      MiddleLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      MiddleRight.spin(directionType::fwd, vel, voltageUnits::volt);
      BackLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      BackRight.spin(directionType::rev, vel, voltageUnits::volt);
    }
    FrontLeft.stop();
    FrontRight.stop();
    MiddleLeft.stop();
    MiddleRight.stop();
    BackLeft.stop();
    BackRight.stop(); 
  }
}

void drivePID(double target, bool drive4 = false, bool driveIntake = false, double kP = 1.4, double kD = 0/*5.5*/){
  if(drive4 == true){
    PTO.set(false);
    double error = 0;
    double prevError;
    LeftDrive4.resetPosition();
    RightDrive4.resetPosition();

    double threshold = 1;
    /*if(target <- 0.0){
      threshold = 1.5;
    }else{
      threshold = 0.7;
    }*/
    double averagePosition = (FrontLeft.position(rotationUnits::deg) + FrontRight.position(rotationUnits::deg))/2 * 10.21*360;
    error = averagePosition - target;
    double derivative;
    prevError = 0;

    
    while(fabs(error) > threshold){
      if(driveIntake == true){
        Intake.spin(directionType::fwd);
      }else{
        Intake.stop();
      }
      averagePosition = (FrontLeft.position(rotationUnits::deg) + FrontRight.position(rotationUnits::deg))/2 * 10.21*360;
      error = averagePosition - target;

      derivative = error - prevError;
      prevError = error;
      double p = error * kP;
      double d = derivative * kD;

      double vel = p + d;

      FrontLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      FrontRight.spin(directionType::fwd, vel, voltageUnits::volt);
      BackLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      BackRight.spin(directionType::fwd, vel, voltageUnits::volt);
    }
    FrontLeft.stop();
    FrontRight.stop();
    BackLeft.stop();
    BackRight.stop();
    Intake.stop(brakeType::coast);
  }else if(drive4 == false && driveIntake == false){
    PTO.set(true);
    double error = 0;
    double prevError;
    LeftDrive4.resetPosition();
    RightDrive4.resetPosition();

    double threshold = 1;
    /*if(target <- 0.0){
      threshold = 1.5;
    }else{
      threshold = 0.7;
    }*/
    double averagePosition = (FrontLeft.position(rotationUnits::deg) + FrontRight.position(rotationUnits::deg))/2 * 10.21*360;
    error = averagePosition - target;
    double derivative;
    prevError = 0;

    
    while(fabs(error) > threshold){
      averagePosition = (FrontLeft.position(rotationUnits::deg) + FrontRight.position(rotationUnits::deg))/2 * 10.21*360;
      error = averagePosition - target;

      derivative = error - prevError;
      prevError = error;
      double p = error * kP;
      double d = derivative * kD;

      double vel = p + d;

      FrontLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      FrontRight.spin(directionType::fwd, vel, voltageUnits::volt);
      MiddleLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      MiddleRight.spin(directionType::fwd, vel, voltageUnits::volt);
      BackLeft.spin(directionType::fwd, vel, voltageUnits::volt);
      BackRight.spin(directionType::fwd, vel, voltageUnits::volt);
    }
    FrontLeft.stop();
    FrontRight.stop();
    MiddleLeft.stop();
    MiddleRight.stop();
    BackLeft.stop();
    BackRight.stop();
    Intake.stop(brakeType::coast);
  }
}
